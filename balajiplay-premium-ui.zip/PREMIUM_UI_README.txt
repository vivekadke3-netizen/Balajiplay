BalajiPlay Premium UI
Original responsive demo UI. DEMO_COIN only; no real-money payments or payouts.
Includes premium dashboard navigation and four demo game entry screens.
