# BalajiPlay Demo v2

Original, demo-only gaming platform scaffold.

### Included
- Next.js responsive web foundation
- NestJS API foundation
- Prisma/PostgreSQL schema
- JWT/Argon2 authentication foundation
- Role hierarchy: Super Master -> Master -> Agent -> Client
- DEMO_COIN virtual wallet model
- Client history fields: bet, payout, win/loss, net P/L
- Exposure and Active Balance definitions
- Four server-side demo-game service stubs: Roulette, Blackjack, Baccarat, Dragon Tiger
- Docker PostgreSQL

### Run
cp .env.example .env
docker compose up -d postgres
cd apps/api && npm install && npx prisma generate && npx prisma migrate dev --name init && npm run start:dev
# second terminal
cd apps/web && npm install && npm run dev

This build deliberately has no real-money deposits, withdrawals, payment gateways, UPI, bank or crypto payout integration.
Before production use, perform a professional security review, add comprehensive tests, rate limiting, refresh-token/session revocation, CSRF protection where applicable, monitoring, backups and deployment hardening.
