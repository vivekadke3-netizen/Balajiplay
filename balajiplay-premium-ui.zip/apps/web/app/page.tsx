"use client";
import Link from "next/link";
export default function Home(){return <main><div className="hero"><div><div className="brand">BalajiPlay</div><h1>Demo Gaming Platform</h1><p>Responsive control panel with virtual DEMO_COIN only.</p><Link href="/dashboard"><button>Open Dashboard</button></Link></div></div></main>}
