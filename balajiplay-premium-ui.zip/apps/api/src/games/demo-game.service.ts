import {BadRequestException,Injectable} from "@nestjs/common";
import {PrismaService} from "../prisma.service";
import {randomInt} from "node:crypto";

@Injectable()
export class DemoGameService {
  constructor(private db:PrismaService){}
  private async assertDemo(userId:string, amount:number){
    if(process.env.DEMO_MODE !== "true") throw new BadRequestException("Demo mode is required");
    if(!Number.isFinite(amount)||amount<=0) throw new BadRequestException("Invalid demo stake");
    const wallet=await this.db.wallet.findUnique({where:{userId}});
    if(!wallet || Number(wallet.balance)<amount) throw new BadRequestException("Insufficient DEMO_COIN");
    return wallet;
  }
  async roulette(userId:string,amount:number,selection:string){
    await this.assertDemo(userId,amount);
    const number=randomInt(0,37);
    const win=selection==="red" ? [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36].includes(number)
      : selection==="black" ? [2,4,6,8,10,11,13,15,17,20,22,24,26,28,29,31,33,35].includes(number)
      : selection==="odd" ? number>0 && number%2===1
      : selection==="even" ? number>0 && number%2===0
      : Number(selection)===number;
    const multiplier=/^\d+$/.test(selection)?36:2;
    return {demo:true,game:"ROULETTE",result:{number},selection,outcome:win?"WON":"LOST",stake:amount,payout:win?amount*multiplier:0,netPnl:win?amount*(multiplier-1):-amount};
  }
  async blackjack(userId:string,amount:number){await this.assertDemo(userId,amount);return {demo:true,game:"BLACKJACK",status:"DEMO_READY",message:"Use the game engine to deal cards server-side."};}
  async baccarat(userId:string,amount:number,selection:string){await this.assertDemo(userId,amount);return {demo:true,game:"BACCARAT",selection,status:"DEMO_READY"};}
  async dragonTiger(userId:string,amount:number,selection:string){await this.assertDemo(userId,amount);return {demo:true,game:"DRAGON_TIGER",selection,status:"DEMO_READY"};}
}