import {Body,Controller,Post,Req,UseGuards} from "@nestjs/common";
import {JwtGuard} from "../auth/jwt.guard";
import {DemoGameService} from "./demo-game.service";
class PlayDto{amount!:number;selection!:string}
@Controller("games") @UseGuards(JwtGuard)
export class DemoGameController{
 constructor(private s:DemoGameService){}
 @Post("roulette/demo") roulette(@Req()r:any,@Body()d:PlayDto){return this.s.roulette(r.user.id,d.amount,d.selection)}
 @Post("blackjack/demo") blackjack(@Req()r:any,@Body()d:PlayDto){return this.s.blackjack(r.user.id,d.amount)}
 @Post("baccarat/demo") baccarat(@Req()r:any,@Body()d:PlayDto){return this.s.baccarat(r.user.id,d.amount,d.selection)}
 @Post("dragon-tiger/demo") dragonTiger(@Req()r:any,@Body()d:PlayDto){return this.s.dragonTiger(r.user.id,d.amount,d.selection)}
}