import {Injectable} from "@nestjs/common"; import {PassportStrategy} from "@nestjs/passport"; import {ExtractJwt,Strategy} from "passport-jwt"; import {PrismaService} from "../prisma.service";
@Injectable() export class JwtStrategy extends PassportStrategy(Strategy){
 constructor(private db:PrismaService){super({jwtFromRequest:ExtractJwt.fromAuthHeaderAsBearerToken(),secretOrKey:process.env.JWT_ACCESS_SECRET!,ignoreExpiration:false})}
 async validate(p:any){const u=await this.db.user.findUnique({where:{id:p.sub},select:{id:true,username:true,role:true,active:true}});return u?.active?u:null;}
}